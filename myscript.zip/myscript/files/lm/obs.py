import subprocess
from time import sleep
subprocess.run("obs --startrecording", shell=True)

