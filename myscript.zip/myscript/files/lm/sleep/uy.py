from time import sleep
import subprocess
subprocess.run("cinnamon-screensaver-command --lock", shell=True)
