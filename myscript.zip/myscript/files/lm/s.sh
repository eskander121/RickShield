# this script can be trigered by clicking ctrl-d or this cript is trigered by lm.py

# run the script that kills python when autenticadet
sleep 0.5
python3 k.py 
# runs script that when authenticated turns off the startup program to run sleep.py 
sleep 1
python3 pe.py 




